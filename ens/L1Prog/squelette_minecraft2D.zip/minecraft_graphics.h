#ifndef MINECRAFT_GRAPHICS_H
#define MINECRAFT_GRAPHICS_H
 
#include "minecraft_types.h"

void win_on_expose(Ez_event *ev);

#endif
