#include "listes_chainees.h"
#include <stdio.h>

/* pour tester les fonctions pas à pas, la macro-définition AVANCEMENT doit
 * être modifiée à mesure que les fonctions nécessaires sont définies */
#define AVANCEMENT 1

int main()
{
    Donnee d;
    printf("\tCréation d'une liste vide et ajout d'éléments :");

    Liste liste = LISTE_VIDE;

    d = 3.14; printf(" "); afficher_donnee(d); inserer_tete(&liste, d);
    d = 1.41; printf(" "); afficher_donnee(d); inserer_tete(&liste, d);
    d = 2.71; printf(" "); afficher_donnee(d); inserer_tete(&liste, d);
    printf("\n");

    afficher_liste(liste); printf("\n");

#if (AVANCEMENT > 1)
    printf("\n\tExtraction d'éléments :");
    /* on supprime des données; attention aux fuites mémoires ! */
    d = extraire_tete(&liste); printf(" "); afficher_donnee(d);
    d = extraire_tete(&liste); printf(" "); afficher_donnee(d);
    printf("\n");

    afficher_liste(liste); printf("\n");
#endif

#if (AVANCEMENT > 2)
    printf("\n\tInsertion d'éléments :");

    d = 1.62; printf(" "); afficher_donnee(d); inserer_tete(&liste, d);
    d = 0.58; printf(" "); afficher_donnee(d); inserer_tete(&liste, d);
    printf("\n");

    afficher_liste(liste); printf("\n");

    Donnee x, y;

    printf("\n\tModification d'une cellule :");
    x = 1.62; printf(" "); afficher_donnee(x);
    y = -1.00; printf(" "); afficher_donnee(y);
    printf("\n");
    /* on recherche une cellule avec la valeur x
     * et on la transforme avec la valeur y si on la trouve;
     * cf. exercice 22(c) du manuel */
    modifier_cellule(&liste, x, y);
    afficher_liste(liste); printf("\n");
#endif

#if (AVANCEMENT > 3)
    printf("\n\tInsertion d'une cellule :");
    x = 3.14; printf(" "); afficher_donnee(x);
    yy = 0.00; printf(" "); afficher_donnee(y);
    printf("\n");
    /* on recherche une cellule avec la valeur x
     * et on rajoute devant une cellule contenant y si on la trouve;
     * cf. exercice 22(b) du manuel */
    inserer_cellule(&liste, x, y);
    afficher_liste(liste); printf("\n");
#endif

#if (AVANCEMENT > 4)
    printf("\n\tSuppression d'une cellule :");
    x = -1.00; printf(" "); afficher_donnee(d);
    printf("\n");
    /* on recherche une cellule avec la valeur -1.00
     * et on la supprime si on la trouve;
     * cf. exercice 22(a) du manuel;
     * attention aux fuites mémoires */
    supprimer_cellule(&liste, x);
    afficher_liste(liste); printf("\n");
#endif

    liberer_liste(liste);

    return 0;
}
