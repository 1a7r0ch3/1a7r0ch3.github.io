#ifndef LISTES_CHAINEES
#define LISTES_CHAINEES

#include <stdlib.h> /* définition du pointeur NULL */

          /********************************************************
           * Module pour manipuler des listes simplement chaînées *
           ********************************************************/
/* cf. Exercice 24, p.31 du manuel de cours 2024-2025 */

/* type de données contenu dans la liste chaînée;
 * peut être facilement changé ici pour être répercuté partout;
 *
 * NOTA: pour l'exemple on utilise un type de donnée de base (float, int, etc.)
 * mais on peut imaginer des données plus complexe, manipulées par valeur ou
 * même par adresse; mais cela implique d'adapter en conséquences les fonctions
 * d'affichage, de gestion mémoire et de comparaison */
typedef float Donnee;

/* _déclaration_ seule de la structure Cellule ;
 * et définitions des types Cellule et Liste */
struct Cellule;
typedef struct Cellule Cellule;
typedef Cellule* Liste;

/* _définition_ de la structure Cellule ;
 * remarquer que la queue est un pointeur sur Cellule */
struct Cellule
{
    Donnee tete; /* donnée immédiatement accessible dans la cellule */
    Liste queue; /* accès aux autres éléments de la liste chaînée */
};

/* puisqu'une Liste est un pointeur sur Cellule, il est pratique de
 * représenter la liste vide par un pointeur nul */
#define LISTE_VIDE NULL

         /********************************************************
          * fonctions de base pour manipuler des listes chaînées *
          ********************************************************/

/* cf. insérer_tête et extraire_tête, p.29 du manuel de cours 2024-2025 */
void inserer_tete(Liste*, Donnee);
Donnee extraire_tete(Liste*);

/* fonctions indispensables pour voir si ça marche */
void afficher_liste(Liste);
void afficher_donnee(const Donnee);

/* libérer toute la mémoire d'une liste chainée */
void liberer_liste(Liste);

                 /******************************************
                  * bonus : fonctions un peu plus évoluées *
                  ******************************************/

/* cf. Exercice 1F, p.30 du manuel de cours 2024-2025 */
void modifier_cellule(Liste*, const Donnee, Donnee);
void inserer_cellule(Liste*, const Donnee, Donnee);
void supprimer_cellule(Liste*, const Donnee);

#endif
