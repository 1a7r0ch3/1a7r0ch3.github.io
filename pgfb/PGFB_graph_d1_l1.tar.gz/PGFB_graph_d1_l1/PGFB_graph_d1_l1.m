function [x, F, Fhist, Thist] = PGFB_graph_d1_l1(Graph, s_d, s_l, iter, recond, verbose)
% PGFB_graph_d1_l1:
% solves problem of the form:
% F(x) =   sum(i)  lambda_l2_i *(x_i-y)^2
%        + sum(i)  lambda_l1_i *abs(x_i)
%        + sum(ij) lambda_d1_ij*abs(x_i-x_j)
% using relaxed preconditioned generalized forward-backward splitting.
%
% Syntax:
%   [x, F, [Fhist], [Thist]] = GFB_graph_d1_l1(Graph, s_d, s_l, [iter=1e3],
%                                              [recond=round(iter/3)], [verbose=false])
% 
% Inputs:
%   Graph   - graph in vector structure obtained through vectorizeGraph
%   s_d     - factor to multiply lambda_d1
%   s_l     - factor to multiply lambda_l1
%   iter    - max number of iteration, (default = [1e3])
%             if nargout > 2, iter(1) is the number of iteration for which one
%             computes the functional value (and recording time if nargout > 3),
%             and iter(2) is the total number of iterations (default = iter(1))
%   recond  - criterion for reconditioning; can be specified as a set of
%             iterations (default = [round(iter/3)]), or as a set of tolerance
%             on the relative norm of the iterate evolution (if the set is
%             exhausted, the value is divided by 10 at each reconditioning)
%   verbose - display information about the process (default = false)
%
% Outputs:
%   if nargout > 3 the algorithm will go in benchmark mode, doing the
%   optimization twice, recording the elapsed time on the first and the
%   functional value on the second
%   x     - final value assigned to each node
%   F     - final value of the functional
%   Fhist - recording of the functional value along the iterations
%   Thist - recording of the elapsed time along the iterations
%
% Reference:
% Raguet, H. & Landrieu, L. Preconditioning of a Generalized Forward-Backward Splitting and Application to Optimization on Graphs
%
% Copyright 2015 Loic Landrieu & Hugo Raguet
%
% This file is part of PGFB_graph_d1_l1. It is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
% PGFB_graph_d1_l1 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License along with PGFB_graph_d1_l1. If not, see <http://www.gnu.org/licenses/>.

if nargin < 4, iter    = 1e3;              end
if nargin < 5, recond  = round(iter(1)/3); end
if nargin < 6, verbose = false;            end
Frec = false;
Trec = false;
if length(iter)==1, iter = [iter iter]; end
if nargout > 2
    Frec  = true;
    Fhist = nan(1,iter(1));
end
if nargout > 3
    Trec  = true;
    Thist = nan(1,iter(1));
end
%===========================META PARAMETERS================================
rho    = 1.5; % relaxation parameter, 0 < rho < 2;
% the following constants ensure that the results stay bounded and are not subject to
% pathological behavior or machine precision issues
e_0    = 1e-16;
e_ampl = 1e-6;
e_diff = 1e-1;
%=========================LOADING DATA=====================================
numberOfNodes = Graph.numberOfNodes;
    % note that for efficiency of implementation, each edge of the original
    % undirected graph is represented here by two directed edges
numberOfEdges = Graph.numberOfEdges;
node2edge     = Graph.nodeToEdge;
edge2node     = Graph.edgeToNode;
sentToReceive = Graph.sentToReceive;
y             = Graph.observation;
if isfield(Graph,'lambda_l2')
    La_l2 = Graph.lambda_l2;
else
    La_l2 = ones(numberOfNodes,1);
end
if isfield(Graph,'lambda_l1')
    La_l1 = s_l*Graph.lambda_l1;
else
    La_l1 = s_l*zeros(numberOfNodes,1);
end
if isfield(Graph,'edgeWeight')
    La_d1 = s_d*Graph.edgeWeight;
else
    La_d1 = s_d*ones(numberOfEdges,1);
end
clear Graph
%===========================FORMATTING=====================================
has_l2       = La_l2~=0;
has_l1       = La_l1~=0;
y            = y(has_l2);
La_l2        = La_l2(has_l2);
La_l1        = La_l1(has_l1);
hasNeigh     = ~isnan(node2edge);
islands      = ~hasNeigh & ~has_l1 & has_l2;
node2edgeNei = node2edge(hasNeigh);
edge2noder   = edge2node(sentToReceive);
%==============INITIALIZING AND PRECONDITIONNING===========================
if verbose,
    fprintf('\nRelaxed preconditioned generalized forward-backward algorithm\n');
end
x          = zeros(numberOfNodes,1);
x(islands) = y(islands(has_l1)); % these won't change
z_l1 = zeros(sum(has_l1),1);   % auxiliary variable for l1 part
z_d1 = zeros(numberOfEdges,1); % auxiliary variable for d1 part
preconditioning(true);     % initial preconditioning
Ga;                        % force Ga to lie in the main workspace
recondNum = 0;
recondVal = recond(1);
%==========================================================================
Xrec = true;
while Xrec || Frec || Trec
if verbose, msg = ''; end
if Frec
    if verbose, fprintf( 'recording functional value... ' ); end
    itEnd = iter(1);
elseif Trec
    if verbose, fprintf( 'recording elapsing time... ' ); end
    % for some reason, calling 'preconditioning(false)' seems to put
    % the internal state of MATLAB in such a way that the following
    % iterations are slightly faster. WHY?
    % Note that the difference is not really significant, but important
    % enough so as to make the PGFB *without reconditioning* slightly
    % slower than PGFB *with reconditioning*, which is aberrant.
    % We thus force one call.
    preconditioning(false); 
    %% reinitializing
    x(~islands) = 0; z_l1(:) = 0; z_d1(:) = 0;
    preconditioning(true);
    recondNum = 0; recondVal = recond(1);
else
    if verbose, fprintf( 'solving... ' ); end
    itEnd   = iter(2) - it;
end
if verbose || Trec, tic; end
%============================OPTIMIZING====================================
for it=1:itEnd
    %-------------reconditioning schedule specified as iterations----------
    if recond > 1
        if it==recondVal
            preconditioning(false);
            recondNum = recondNum+1; 
            recondVal = recond(max(length(recond),recondNum));
        end
    else
        x_old = x;
    end
    %----------computing the explicit step---------------------------------
    p = 2 * x;
    p(has_l2)  = p(has_l2) - GaLa_l2.*(x(has_l2) - y);
    %----------compute the proximity operator of d1------------------------
    tmp1 = p(edge2node) - z_d1; % the argument of the prox operator
    tmp2 = tmp1(sentToReceive);
        % we now compute the prox. first the weighted average:
    tmp3 = WGa_d1.*tmp1 + WGa_d1r.*tmp2;
    tmp1 = (tmp1 - tmp2); % the gradient on the graph
        % soft thresholding
    tmp1 = tmp3 + WGa_d1r.*(max(1-softThrd_d1./abs(tmp1),0).*tmp1);
    z_d1 = z_d1 + rho * (tmp1 - x(edge2node)); % update z_d1
    %----------compute the proximity operator of l1------------------------
    tmp1 = p(has_l1) - z_l1; % the argument of the prox operator
    tmp1 = max(1-softThrd_l1./abs(tmp1),0).*tmp1;
    z_l1 = z_l1 + rho * (tmp1 - x(has_l1)); % update z_l1
    %----------update x----------------------------------------------------
    x(~islands) = 0;
    tmp1 = cumsum(W_d1.*z_d1);
    tmp2 = tmp1(node2edgeNei(2:end)-1);
    x(hasNeigh)  = tmp1([node2edgeNei(2:end)-1;numberOfEdges]) - [0;tmp2];
    x(has_l1)    = x(has_l1) + W_l1.*z_l1;
    %----------reconditioning specified as relative iterate evolution------
    if (recondVal < 1) && (norm(x-x_old)./max(norm(x_old), e_0) < recondVal)
        preconditioning(false);
        recondNum = recondNum+1;
        if length(recond) > recondNum;
            recondVal = recond(recondNum+1);
        else
            recondVal = recondVal/10;
        end
    end
    %-------------benchmark recording--------------------------------------
    if Frec
        F_l2 = .5 * sum(La_l2.*(x(has_l2) - y).^2);
        F_l1 =      sum(La_l1.*abs(x(has_l1)));
            % each edge is counted twice
        F_d1 = .5 * sum(La_d1.*abs(x(edge2node) - x(edge2noder)));
        Fhist(it) = F_l2 + F_l1 + F_d1;
    elseif Trec
        Thist(it) = toc;
    end
    %-------------info on the progress--------------------------------------
    if verbose && (mod(it,50)==0) && (Frec||~Trec)
        msg = time_box(toc,it,itEnd,msg);
    end
end %endfor it
    if verbose
        if Frec || ~Trec, fprintf(repmat(sprintf('\b'),1,length(msg))); end
        fprintf('done.\n');
    end
    if Frec
        Frec = false;
    elseif Trec
        Trec = false;
    else
        Xrec = false;
    end
end %endwhile it
% compute final functional value
if verbose || (nargout > 1)
    F_l2 = .5 * sum(La_l2.*(x(has_l2) - y).^2);
    F_l1 =      sum(La_l1.*abs(x(has_l1)));
        % each edge is counted twice
    F_d1 = .5 * sum(La_d1.*abs(x(edge2node) - x(edge2noder)));
    F    = F_l2 + F_l1 + F_d1;
end
if verbose
    msg = sprintf(['Data fidelity : %1.4e \nl1 penalty    : %1.4e\n', ...
                   'd1 penalty    : %1.4e \nTotal loss    : %1.4e\n'], ...
                                                    F_l2, F_l1, F_d1, F);
    fprintf(msg);
end

function preconditioning(isIni)
%---------estimate the magnitude of the values-----------------------------
if isIni
    avrg = max(mean(abs(y)), e_0);
    m_l1 = La_l1./avrg;
    m_d1 = La_d1./avrg;
else
    avrg = max(mean(abs(x)));
    e_l1 = max(e_ampl*avrg, e_0);
    ampl = max(abs(x), e_l1);
    e_d1 = max(e_diff*ampl(edge2node), e_l1);
    diff = max(abs(x(edge2node)-x(edge2noder)), e_d1);
    m_l1 = La_l1./ampl(has_l1);
    m_d1 = La_d1./diff;
    %% get the auxiliary subgradients
    p = x;
    p(has_l2) = p(has_l2) - GaLa_l2.*(x(has_l2) - y);
    z_d1 = (W_d1./Ga(edge2node)).*(p(edge2node) - z_d1);
    z_l1 = (W_l1./Ga(has_l1))   .*(p(has_l1)    - z_l1);
end
%----compute a diagonal estimation of the hessians of each functional-------
M_l1 = zeros(numberOfNodes,1);
M_l2 = zeros(numberOfNodes,1);
M_d1 = zeros(numberOfNodes,1);
M_l1(has_l1) = m_l1;
M_l2(has_l2) = La_l2;
    % for each node sum m_d1 of all the edges of which it is the origin
tmp1 = cumsum(m_d1);
tmp2 = tmp1(node2edgeNei(2:end)-1);
M_d1(hasNeigh) = tmp1([node2edgeNei(2:end)-1;numberOfEdges]) - [0;tmp2];
%---------computation of Gamma---------------------------
% we approximate the inverse of the hessian by the inverse of its diagonal
% we add the contribution of each functional
Ga = 1./(M_d1 + M_l1 + M_l2);
% ensure that the explicit step is alpha-average
Ga(has_l2) = min(0.99*(4-2*rho)./La_l2,Ga(has_l2));
%--------computation of the splitting weights W-----------------------------
W_l1 = m_l1./(M_d1(has_l1) + M_l1(has_l1));
W_d1 = m_d1./(M_d1(edge2node) + M_l1(edge2node));
clear m_l1 m_d1 M_l2 M_l1 M_d1
%----------------update the auxiliary variables-----------------------------
if ~isIni
    p = x;
    p(has_l2) = p(has_l2) - Ga(has_l2).*La_l2.*(x(has_l2) - y);
    z_d1 = p(edge2node) - (Ga(edge2node)./W_d1).*z_d1;
    z_l1 = p(has_l1)    - (Ga(has_l1)./W_l1)   .*z_l1;
end
%----------precomputation of some quantities--------------------------------
WGa_d1      = W_d1./Ga(edge2node);
WGa_d1r     = WGa_d1(sentToReceive);
WGa_d1m     = max(WGa_d1 + WGa_d1r, e_0);
softThrd_d1 = La_d1.*WGa_d1m./max(WGa_d1.*WGa_d1r, e_0);
softThrd_l1 = La_l1         ./max(W_l1./Ga(has_l1), e_0);
GaLa_l2     = Ga(has_l2).*La_l2;
WGa_d1      = WGa_d1 ./WGa_d1m;
WGa_d1r     = WGa_d1r./WGa_d1m;
clear WGa_d1m
end %preconditining

end %PGFB_graph_d1_l1
