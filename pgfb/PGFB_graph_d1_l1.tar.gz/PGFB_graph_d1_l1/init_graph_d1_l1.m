clear all;
dataset = 'revenue'
% dataset = 'population'
% dataset = 'election'
load(dataset);

% typical values used in numerical applications
% revenue
s_d = 5e-1
s_l = 3e-3
% population
% s_d = 1e2
% s_l  = 0
% election
% s_d = 1e-2
% s_l = 0;

% benchmark parameters
iterBench   =  1000
iterInf     =  5000
verbose     = true
saveResults = true % need custom routines

% reconditioning tolerance
recond0 = 0
recond1 = 1e-3
recond2 = 1e-4
recond3 = 1e-5
