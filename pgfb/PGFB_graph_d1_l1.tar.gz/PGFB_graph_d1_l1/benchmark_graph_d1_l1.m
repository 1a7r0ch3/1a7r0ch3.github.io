% [dump, dump, F_PPD,   T_PPD]   = PPD_graph_d1_l1(GraphVec,  s_d, s_l, iterBench, verbose);
% [dump, dump, F_IPPD,  T_IPPD]  = IPPD_graph_d1_l1(GraphVec, s_d, s_l, iterBench, verbose);
% [dump, dump, F_PGFB0, T_PGFB0] = PGFB_graph_d1_l1(GraphVec, s_d, s_l, ...
%                                                               iterBench, recond0, verbose);
% [dump, dump, F_PGFB1, T_PGFB1] = PGFB_graph_d1_l1(GraphVec, s_d, s_l, ...
%                                                               iterBench, recond1, verbose);
% [dump, Finf, F_PGFB2, T_PGFB2] = PGFB_graph_d1_l1(GraphVec, s_d, s_l, ...
%                                                     [iterBench iterInf], recond2, verbose);
[dump, dump, F_PGFB3, T_PGFB3] = PGFB_graph_d1_l1(GraphVec, s_d, s_l, ...
                                                              iterBench, recond3, verbose);

clf
hold on
plot(T_PPD,   log10((F_PPD   - Finf)/Finf), 'b' , 'LineWidth', 2);
plot(T_IPPD,  log10((F_IPPD  - Finf)/Finf), 'c' , 'LineWidth', 2);
plot(T_PGFB0, log10((F_PGFB0 - Finf)/Finf), 'r--', 'LineWidth', 2);
plot(T_PGFB1, log10((F_PGFB1 - Finf)/Finf), 'r' ,  'LineWidth', 2);
plot(T_PGFB2, log10((F_PGFB2 - Finf)/Finf), 'm',   'LineWidth', 2);
plot(T_PGFB3, log10((F_PGFB3 - Finf)/Finf), 'y',   'LineWidth', 2);
xlabel('Time in seconds','FontSize',14);
ylabel('log($\frac{F_t - F_{\infty}}{F_{\infty}}$)','FontSize',14,'interpreter','latex');
legend({'PPD', 'IPPD', 'PGFB0', 'PGFB1', 'PGFB2', 'PGFB3' }, 'FontSize', 12, 'Location', 'NorthEast');

if saveResults % needs custom routines
    exp_path = sprintf( '%s_sd_%s_sl_%s_it_%s_%s', dataset, e2str(s_d,1), ...
                                    e2str(s_l,1), e2str(iterBench,1), e2str(iterInf,1) );
    exp_path = fullfile(fileparts(which('benchmark_graph_d1_l1.m')), 'Results', exp_path);
    list2pst(T_PPD,   F_PPD,   '%s_PPD.dat',     exp_path);
    list2pst(T_IPPD,  F_IPPD,  '%s_IPPD.dat',    exp_path);
    list2pst(T_PGFB0, F_PGFB0, '%s_PGFB_%s.dat', exp_path, e2str(recond0,1));
    list2pst(T_PGFB1, F_PGFB1, '%s_PGFB_%s.dat', exp_path, e2str(recond1,1));
    list2pst(T_PGFB2, F_PGFB2, '%s_PGFB_%s.dat', exp_path, e2str(recond2,1));
    list2pst(T_PGFB3, F_PGFB3, '%s_PGFB_%s.dat', exp_path, e2str(recond3,1));
    list2pst(Finf,    [],      '%s_Finf.dat',    exp_path);
    epsprint( exp_path );
end
