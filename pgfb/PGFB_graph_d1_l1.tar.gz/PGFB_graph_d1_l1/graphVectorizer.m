function GraphVector = graphVectorizer2(Graph)
% GRAPHVECTORIZER convert a graph structure to a vectorized format
%
%SYNTAX :
%
%Graph - necessary fields
%    - neighbors  : a cell of size N the number of nodes, listing the 
%                   neighbors of the node
%    - observation: a vector of size NxD, with a value associated to each 
%                   node
%
%Graph - optional fields
%    - edgeWeight  : for edge-weighted graphs, a cell of size N with the weight 
%                    of each edge in the same order they are presented in neighbors.
%                    defaults is 1 for all edges
%Outputs : 
%   Graph a structure with fields:
%   numberOfNodes - the number of nodes.
%   numberOfEdges - the number of edges.
%   nodeToEdge    - for each node the edge index of the first edge leaving 
%                   the node. From a node n leaves edges with index 
%                   nodeToEdge(n) to nodeToEdge(n+1)-1.
%   edgeToNode    - for each edge the node index of the origin node of the
%                   edge.
%   sentToReceive - for each edge the edge index of the reversed edge.
%   observation   - observation.
%   edgeWeight     = the vectorized edgeweight array
%Note: to account for nodes without neighbors/edges, we the last edge is a 
%fake edge
%
% Copyright 2015 Loic Landrieu
%
% This file is part of PGFB_graph_d1_l1. It is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
% PGFB_graph_d1_l1 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License along with PGFB_graph_d1_l1. If not, see <http://www.gnu.org/licenses/>.

if (isfield(Graph,'neighbors'))
    neighbors = Graph.neighbors;
else
    error('Graph needs neighbors fields');
end
numberOfNodes  = numel(neighbors);
if (size(neighbors,2)>size(neighbors,1))
    neighbors = neighbors';
end
if (isfield(Graph,'observation'))
    observation = Graph.observation;
else
    error('Graph needs observation fields');
end
if (isfield(Graph,'edgeWeight'))
    edgeWeight = Graph.edgeWeight;
    if (size(edgeWeight,2)>size(edgeWeight,1))
        edgeWeight = edgeWeight';
    end
else
    edgeWeight = cell(numberOfNodes,1);
    for node = 1 : numberOfNodes
        edgeWeight{node} = ones(size(neighbors{node}));
    end
end
if (( size(edgeWeight,1)~=numberOfNodes)...
  || (size(observation,1)~=numberOfNodes))
    error('all arguments must be of size N the number of nodes');
end
%-------------CONSTRUCTING THE EDGES INDEX---------------------------------
numberOfEdgesE = 6 * numberOfNodes;
%we first need to go through all edges to assign indexes
numberOfEdges  = 1;
numberOfNeigh  = nan(numberOfNodes, 1); %number of neighbors
%for each node the edge index of the first edge leaving the node. From 
%a node n leaves edges with index nodeToEdge(n) to nodeToEdge(n+1)-1.
nodeToEdge     = nan(numberOfNodes, 1);
%for each edge the node index of the origin node of the edge.
edgeToNode     = NaN(numberOfEdgesE,1);
tic;
reverseStr = '';
fprintf('1/2 Constructing edges index : ');
for node = 1 : numberOfNodes
    %for each node we create numberOfNeigh new edges index of all gthe
    %edges that leaves this nodes.
    %numberOfEfge - 1 is the index of the last edge index assigned
    numberOfNeigh(node) = numel(neighbors{node});    
    if (numberOfNeigh(node)==0)
        continue;
    end
    nodeToEdge(node)    = numberOfEdges;
    %we update numberOfEdges
    numberOfEdges       = numberOfEdges + numberOfNeigh(node);
    %all the edges are leaving node
    edgeToNode(nodeToEdge(node):(nodeToEdge(node)+numberOfNeigh(node)-1))...
                        = node;
    if (numberOfEdges>0.9*numberOfEdgesE)
        edgeToNode2 = nan(numberOfEdgesE * 2,1);
        edgeToNode2(1:numberOfEdgesE) = edgeToNode2;
        edgeToNode = edgeToNode2;
        clear('edgeToNode2');
        numberOfEdgesE = 2 * edgeToNodeE;
    end
    %-------------TIME BOX-------------------------------------------------
    if (mod(node,50000)==0)
	ratio         = (node)/(numberOfNodes);
    remainingTime = toc * (1 - ratio) / ratio;
    msg = sprintf('%3.0f %%%% => Xp : %d / %d, Reamining time = %s\n'...
              ,ceil(100 * ratio) ,node,numberOfNodes,...
              formatTime(remainingTime));
    fprintf([reverseStr,msg]);
    reverseStr = repmat(sprintf('\b'), 1, length(msg)-1);
    end
    %--------------------------------------------------------------------                 
end
numberOfEdges   = numberOfEdges - 1; 
edgeToNode      = edgeToNode(1:numberOfEdges);
edgeWeightArray = NaN(1, numberOfEdges); 
sentToReceive   = NaN(1, numberOfEdges); %index of the reversed edge.
tic;
reverseStr = '';
fprintf('2/2 Vectorizing edge structure : ');
%-------------CONSTRUCTING THE EDGES INDEX---------------------------------
for node = 1 : numberOfNodes
    if (numberOfNeigh(node)==0)
        continue;
    end
    %we store the edge weight in the order we met them
    edgeWeightArray(nodeToEdge(node):(nodeToEdge(node)  ...
                + numberOfNeigh(node) - 1)) = edgeWeight{node};
    % the cumulative sum of the number of neigbors of each neighbor
    lengthArray = cumsum([0,cellfun(@length...
                ,{neighbors{neighbors{node}}})]);
    lengthArray = lengthArray(1:(end-1));
    %compute the index of the reverses edges
    sentToReceive(nodeToEdge(node):(nodeToEdge(node)...
                + numberOfNeigh(node) - 1)) ...
                = nodeToEdge(neighbors{node})' ...
                + find(([neighbors{neighbors{node}}]==node)) ...
                - lengthArray - 1;
    %-------------TIME BOX-------------------------------------------------
    if (mod(node,50000)==0)
	ratio         = (node)/(numberOfNodes);
    remainingTime = toc * (1 - ratio) / ratio;
    msg = sprintf('%3.0f %%%% => Xp : %d / %d, Reamining time = %s\n'...
              ,ceil(100 * ratio) ,node,numberOfNodes,...
              formatTime(remainingTime));
    fprintf([reverseStr,msg]);
    reverseStr = repmat(sprintf('\b'), 1, length(msg)-1);
    end
    %--------------------------------------------------------------------        
end
%------------------CONSTRUCTING THE GRAPH STRUCTURE------------------------
GraphVector               = struct;
GraphVector.numberOfNodes = numberOfNodes;
GraphVector.numberOfEdges = numberOfEdges;
GraphVector.nodeToEdge    = nodeToEdge;
GraphVector.edgeToNode    = edgeToNode;
GraphVector.sentToReceive = sentToReceive;
GraphVector.observation   = observation;
GraphVector.edgeWeight    = edgeWeightArray';
