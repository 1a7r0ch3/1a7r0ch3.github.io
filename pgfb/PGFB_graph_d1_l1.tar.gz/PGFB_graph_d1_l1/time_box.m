function msg = time_box(t,it,itEnd,msg)
%
%        msg = time_box(t,it,itEnd,msg)
%
% Copyright 2015 Loic Landrieu & Hugo Raguet
%
% This file is part of PGFB_graph_d1_l1. It is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
% PGFB_graph_d1_l1 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License along with PGFB_graph_d1_l1. If not, see <http://www.gnu.org/licenses/>.

r = it/itEnd;
t_rem = t * (1 - r)/r;
rev = repmat(sprintf('\b'), 1, length(msg));
msg = sprintf(['\niteration #%d/%d; ', ...
               'remaining time: %s; ', ...
               'average time per iteration: %2.3fs\n'], ...
               it, itEnd, format_time(t_rem), t/it);
fprintf([rev, msg]);

function t_dhms = format_time(t_s)
% convert a duration in second (real number)
% to a duration in days hour, minutes, seconds (string)
d = floor(t_s/(3600*24));
s = t_s - 3600*24*d;
h = floor(s/3600);
s = s - 3600*h;
m = floor(s/60);
s = s - 60 * m;
t_dhms = '';
if d > 0, t_dhms = [t_dhms sprintf('%d days, ', d)];  end
if h > 0, t_dhms = [t_dhms sprintf('%d hours, ', h)]; end
if m > 0, t_dhms = [t_dhms sprintf('%d min., ', m)];  end
t_dhms = [t_dhms  sprintf('%d sec.', floor(s))];
end %format_time

end %time_box
