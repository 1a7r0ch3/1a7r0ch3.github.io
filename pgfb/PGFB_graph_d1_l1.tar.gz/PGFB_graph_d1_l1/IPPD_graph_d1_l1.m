function [x, F, Fhist, Thist] = IPPD_graph_d1_l1(Graph, s_d, s_l, iter, verbose)
% IPPD_graph_d1_l1:
% solves problem of the form:
% F(x) =   sum(i)  lambda_l2_i *(x_i-y)^2
%       + sum(i)  lambda_l1_i *abs(x_i)
%       + sum(ij) lambda_d1_ij*abs(x_i-x_j)
% using inertial preconditioned primal-dual splitting.
% 
% Syntax:
%   [x, F, [Fhist], [Thist]] = PCP_graph_d1_l1(Graph, s_d, s_l, [iter=1e3], [verbose=false])
% 
% Inputs:
%   Graph   - graph in vector structure obtained through vectorizeGraph
%   s_d     - factor to multiply lambda_d1
%   s_l     - factor to multiply lambda_l1
%   iter    - max number of iteration, (default = [1e3])
%             if nargout > 2, iter(1) is the number of iteration for which one
%             computes the functional value (and recording time if nargout > 3),
%             and iter(2) is the total number of iterations (default = iter(1))
%   verbose - display information about the process (default = false)
%
% Outputs:
%   if nargout > 3 the algorithm will go in benchmark mode, doing the
%   optimization twice, recording the elapsed time on the first and the
%   functional value on the second 
%   x     - final value assigned to each node
%   F     - final value of the functional
%   Fhist - recording of the functional value along the iterations
%   Thist - recording of the elapsed time along the iterations
%
%
% Reference:
% Lorenz, D. & Pock, T. An Inertial Forward-Backward Algorithm for Monotone Inclusions Journal of Mathematical Imaging and Vision, Springer US, 2015, 51, 311-325 
%
% Copyright 2015 Loic Landrieu & Hugo Raguet
%
% This file is part of PGFB_graph_d1_l1. It is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
% PGFB_graph_d1_l1 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License along with PGFB_graph_d1_l1. If not, see <http://www.gnu.org/licenses/>.

if nargin < 4, iter    = 1e3;   end
if nargin < 5, verbose = false; end
Frec = false;
Trec = false;
if length(iter)==1, iter = [iter iter]; end
if nargout > 2
    Frec  = true;
    Fhist = nan(1,iter(1));
end
if nargout > 3
    Trec  = true;
    Thist = nan(1,iter(1));
end
%===========================META PARAMETERS================================
r    = 1; % scaling between primal and dual step
gamm = 1; % normalized explicit step size, 0 < gamm < 2
alph_r = 0.5; % ratio to maximum inertial parameter;
%=========================LOADING DATA=====================================
numberOfNodes = Graph.numberOfNodes;
    % note that for efficiency of implementation, each edge of the original
    % undirected graph is represented here by two directed edges
numberOfEdges = Graph.numberOfEdges;
node2edge     = Graph.nodeToEdge;
edge2node     = Graph.edgeToNode;
sentToReceive = Graph.sentToReceive;
y             = Graph.observation;
if isfield(Graph,'lambda_l2')
    La_l2 = Graph.lambda_l2;
else
    La_l2 = ones(numberOfNodes,1);
end
if isfield(Graph,'lambda_l1')
    La_l1 = s_l*Graph.lambda_l1;
else
    La_l1 = s_l*ones(numberOfNodes,1);
end
if isfield(Graph,'edgeWeight')
    La_d1 = s_d*Graph.edgeWeight;
else
    La_d1 = s_d*ones(numberOfEdges,1);
end
clear Graph
%===========================FORMATTING=====================================
has_l2       = La_l2~=0;
has_l1       = La_l1~=0;
nb_l1        = nnz(has_l1);
La_l1        = La_l1(has_l1);
y            = y(has_l2);
La_l2        = La_l2(has_l2);
hasNeigh     = ~isnan(node2edge);
node2edgeNei = node2edge(hasNeigh);  
edge2noder   = edge2node(sentToReceive);
%==============INITIALIZING AND PRECONDITIONNING===========================
if verbose
    fprintf('\nInertial preconditioned primal-dual algorithm\n');
end
% Sigm_d1 = r./La_d1;
% Sigm_l1 = r./La_l1;
% there is actually no need for computing Sigm !
Tau           = zeros(numberOfNodes,1);
tmp1          = cumsum(r*La_d1);
tmp2          = tmp1(node2edgeNei(2:end)-1);
Tau(hasNeigh) = tmp1([node2edgeNei(2:end)-1;numberOfEdges]) - [0;tmp2];
Tau(has_l1)   = Tau(has_l1) + r * La_l1;
Tau(has_l2)   = Tau(has_l2) + La_l2 / gamm;
Tau           = 1 ./ Tau;
x       = zeros(numberOfNodes,1);
z_l1    = zeros(sum(has_l1),1);   % dual variable for l1 part
z_d1    = zeros(numberOfEdges,1); % dual variable for d1 part
xold    = x;    % store x at previous iteration
zold_l1 = z_l1; % store z_l1
zold_d1 = z_d1; % store z_d1
% inertial parameter
alph = alph_r*(1 + (sqrt(9 - 4*gamm) - 3)/gamm);
alph = max(0,alph);
%==========================================================================
iterSum = 0;
while (iterSum < iter(2)) || Frec || Trec
if verbose, msg = ''; end
if Frec
    if verbose, fprintf( 'recording functional value... ' ); end
    iterEnd = iter(1);
elseif Trec
    if verbose, fprintf( 'recording elapsing time... ' ); end
    iterEnd = iter(1);
else
    if verbose, fprintf( 'solving... ' ); end
    iterEnd = iter(2)-iterSum;
end
if verbose || Trec, tic; end
%============================OPTIMIZING====================================
for it=1:iterEnd 
    % we have the following scheme: cf (30)
    %   where G=0, P=0, Q = l2^2, F(K(x)) = l1+d1.
    % xx_k     = x_k  + alph * (x_k - x_{k-1})
    % zz_k     = z_k  + alph * (z_k - z_{k-1})
    % x_{k+1}  = xx_k - Tau  * (gradQ(xx_k) + K'(zz_k))
    % z_{k+1}  = prox_{Sigm*F'}(zz_k + Sigm*K(2 x_{k+1} - xx_k))
    %----------computing inertial variables--------------------------------
    xx      = x    + alph * (x    - xold);
    zz_d1   = z_d1 + alph * (z_d1 - zold_d1);
    zz_l1   = z_l1 + alph * (z_l1 - zold_l1);
    xold    = x;
    zold_d1 = z_d1;
    zold_l1 = z_l1;
    %---------- update x---------------------------------------------------
    % we compute K'(zz)
    tmp3 = zeros(numberOfNodes,1);
        % first the d1 part
    tmp1 = cumsum(La_d1.*zz_d1);
    tmp2 = tmp1(node2edgeNei(2:end)-1);
    tmp3(hasNeigh) = tmp1([node2edgeNei(2:end)'-1,numberOfEdges]) - [0;tmp2];
        % then the l1 part
    tmp3(has_l1) = tmp3(has_l1) + La_l1.*zz_l1;
    % now the gradient descent
    tmp3(has_l2) = tmp3(has_l2) + La_l2.*(xx(has_l2) - y);
    x            = xx - Tau.*tmp3;
    %---------- update z---------------------------------------------------
    tmp1 = 2*x - xx;
    % Moreau's identity: prox_{Sigm*F'}(u) = u - Sigm*prox_{F/Sigm}(u/Sigm)
    % first we compute the argument
    % recall: Sigm_d1.*La_d1 = r and Sigm_l1.*La_l1 = r
    tmp2 = zz_d1 + 0.5*r*(tmp1(edge2node) - tmp1(edge2noder));
    tmp3 = zz_l1 + r*tmp1(has_l1);
    % now prox_{Sigm*F'}
    z_d1 = tmp2 - max(1 - 1./abs(tmp2),0).*tmp2;
    z_l1 = tmp3 - max(1 - 1./abs(tmp3),0).*tmp3;
    %-------------TIME BOX-------------------------------------------------
    if verbose && (mod(it,50)==0) && (Frec||~Trec)
        msg = time_box(toc,it,iterEnd,msg);
    end
    %-------------benchmark recording--------------------------------------
    if Frec
        F_l2 = .5 * sum(La_l2.*(x(has_l2) - y).^2);
        F_l1 =      sum(La_l1.*abs(x(has_l1)));
            % each edge is counted twice
        F_d1 = .5 * sum(La_d1.*abs(x(edge2node) - x(edge2noder)));
        Fhist(it) = F_l2 + F_l1 + F_d1;
    elseif Trec
        Thist(it) = toc;
    end
    %----------------------------------------------------------------------
end %endfor it
    if verbose
        if Frec || ~Trec, fprintf(repmat(sprintf('\b'),1,length(msg))); end
        fprintf('done.\n');
    end
    if Frec
        Frec = false;
    elseif Trec
        Trec = false;
    end
    iterSum = iterSum+iterEnd;
end %endwhile iterSum<iter(2)
% compute final functional value
if verbose || (nargout > 1)
    F_l2 = .5 * sum(La_l2.*(x(has_l2) - y).^2);
    F_l1 =      sum(La_l1.*abs(x(has_l1)));
        % each edge is counted twice
    F_d1 = .5 * sum(La_d1.*abs(x(edge2node) - x(edge2noder)));
    F    = F_l2 + F_l1 + F_d1;
end
if verbose
    msg = sprintf(['Data Fidelity : %1.4e \nl1 Penalty    : %1.4e\n', ...
                   'd1 penalty    : %1.4e \nTotal Loss    : %1.4e\n'], ...
                                         F_l2, F_l1, F_d1, F);
    fprintf(msg);
end

end %IPPD_graph_d1_l1
